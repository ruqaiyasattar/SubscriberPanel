package ha.ecz.com.subscriberpanel;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.Request;
import com.daimajia.slider.library.SliderLayout;
import com.daimajia.slider.library.SliderTypes.BaseSliderView;
import com.daimajia.slider.library.SliderTypes.TextSliderView;
import com.daimajia.slider.library.Tricks.ViewPagerEx;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import ha.ecz.com.subscriberpanel.RESTService.CVJSONObjectResp;
import ha.ecz.com.subscriberpanel.RESTService.VolleyCallback;
import ha.ecz.com.subscriberpanel.Utils.Utilities;


public class LoginActivity extends AppCompatActivity implements ViewPagerEx.OnPageChangeListener {

    private Context _objContext;
    private ImageView _imgMenubutton;// Actionbar
    private SliderLayout _topSlider;
    private EditText _txtUserEmail, _txtUserPassword;
    private Button _btnSignIn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        _objContext = getApplicationContext();

        // Get the widget reference from XML layout
        _txtUserEmail = (EditText) findViewById(R.id.txtUserEmail);
        _txtUserPassword = (EditText) findViewById(R.id.txtUserPassword);
        _btnSignIn = (Button) findViewById(R.id.btnSignIn);

        SetCustomActionBar();
        InitSlider();

        _btnSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (_txtUserEmail.getText().toString().length() == 0) {
                    Toast.makeText(_objContext, "Please enter valid Email Address",
                            Toast.LENGTH_SHORT).show();

                }else if(_txtUserPassword.getText().toString().length() == 0){
                    Toast.makeText(_objContext, "Please enter valid Password",
                            Toast.LENGTH_SHORT).show();
                }
                else {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("UserEmail", _txtUserEmail.getText().toString());
                    params.put("Password", _txtUserPassword.getText().toString());

                    CVJSONObjectResp objRR = new CVJSONObjectResp();
                    objRR.JSONReqResp(LoginActivity.this, Request.Method.POST,
                            "ApplicationUsers/POSTLogIn", new VolleyCallback() {
                                @Override
                                public void onSuccess(JSONObject result) throws JSONException {
                                    //JSONObject objRes = result;
                                    if (result != null) {
                                        if(result.length() > 0){
                                            //ApplicationUser objApp = _objGSON.fromJson(result.toString(), ApplicationUser.class);

                                            Utilities.setPreference(_objContext, "adminObj", result.toString());

                                            Intent i = new Intent(LoginActivity.this, DashboardActivity.class);
                                            startActivity(i);
                                            finish();
                                        }
                                    }
                                }
                                @Override
                                public void onError(String result) throws Exception {
                                    Log.e("Err From Out Call", result);
                                    Toast.makeText(_objContext, result,
                                            Toast.LENGTH_SHORT).show();
                                }
                                }, params);
                }
            }
        });

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        //getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    private void SetCustomActionBar() {

        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setCustomView(R.layout.custom_action_bar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayShowCustomEnabled(true);
        getSupportActionBar().setDisplayUseLogoEnabled(false);
        getSupportActionBar().setDisplayShowHomeEnabled(false);
        getSupportActionBar().setBackgroundDrawable(_objContext.getResources().getDrawable(
                        R.drawable.drawable_actionbar_back));
        _imgMenubutton = (ImageView) findViewById(R.id.imgMenu);
        _imgMenubutton.setVisibility(View.GONE);

    }

    private void InitSlider() {
        _topSlider = (SliderLayout) findViewById(R.id.slider);

        HashMap<String, Integer> file_maps = new HashMap<String, Integer>();
        file_maps.put("One", R.drawable.slider_image_1);
        file_maps.put("Two", R.drawable.slider_image_2);
        file_maps.put("Three", R.drawable.slider_image_3);

        for (String name : file_maps.keySet()) {
            TextSliderView textSliderView = new TextSliderView(this);
            // initialize a SliderLayout
            textSliderView
                    .image(file_maps.get(name))
                    .setScaleType(BaseSliderView.ScaleType.Fit);

            //add your extra information
            textSliderView.bundle(new Bundle());
            textSliderView.getBundle()
                    .putString("extra", name);

            _topSlider.addSlider(textSliderView);
        }
        _topSlider.setPresetTransformer(SliderLayout.Transformer.Background2Foreground);
        _topSlider.setDuration(2000);
        _topSlider.addOnPageChangeListener(this);
    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
    }

    @Override
    public void onPageSelected(int position) {
        Log.d("Slider Demo", "Page Changed: " + position);
    }

    @Override
    public void onPageScrollStateChanged(int state) {
    }

   /* @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }*/
}
