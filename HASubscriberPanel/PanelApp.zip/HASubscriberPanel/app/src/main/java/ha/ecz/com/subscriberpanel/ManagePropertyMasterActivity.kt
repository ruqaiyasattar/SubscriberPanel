package ha.ecz.com.subscriberpanel


import android.app.ProgressDialog
import android.os.AsyncTask
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

import ha.ecz.com.subscriberpanel.Models.ManageProperty
import ha.ecz.com.subscriberpanel.R.id

import java.util.ArrayList
import java.util.HashMap

import ha.ecz.com.subscriberpanel.Utils.Parser
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

class ManagePropertyMasterActivity : AppCompatActivity() {
    private lateinit var pd: ProgressDialog
    private var obj: ManagerPropertyTask? = null

    private var model: ManageProperty? = null
    private var getData: GetData? = null
    private var spinner: Spinner? = null
    private var key: String? = null
    private var count = 1
    private var spPropertyType: Spinner? = null
    private var spCity: Spinner? = null
    private var spPurpose: Spinner? = null
    private var spCurrency: Spinner? = null
    private var spAreaUnit: Spinner? = null
    private var spStatus: Spinner? = null
    private var spPrivacy: Spinner? = null
    private var URL: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        this.setContentView(R.layout.activity_manage_property_master)

        val txtTitle = findViewById<View>(R.id.txtPropertyTitle) as TextView
        val txtPrice = findViewById<View>(R.id.txtPrice) as TextView
        val txtLandArea = findViewById<View>(id.txtLandArea) as TextView
        val txtAddress = findViewById<TextView>(id.txtPropAddress)
        val txtDescription = findViewById<TextView>(id.txtDescription)
        spStatus = findViewById(id.cmbActive)
        spPropertyType = findViewById(id.cmbPropertyType)
        spCurrency = findViewById(id.cmbCurrency)
        spCity = findViewById(id.cmbCity)
        spAreaUnit = findViewById(id.cmbAreaUnit)
        spPurpose = findViewById(id.cmbPurpose)
        spPrivacy = findViewById(id.cmbPrivacy)
        val btnSubmit = findViewById<Button>(R.id.submit_data)

        GetAsync()

        btnSubmit.setOnClickListener {
            model = ManageProperty()
            model!!.title = txtTitle.text.toString()
            model!!.propertyCategoryID = 4
            model!!.cityID = 14
            model!!.streetRoadName = "nazimabad"
            model!!.address = txtAddress.text.toString()
            model!!.locationAlias = "LocationAlias"
            model!!.address_Component = "Address"
            model!!.subLocalityLevel = "SubLocalityLevel"
            model!!.latitude = 24.8604
            model!!.longitude = 67.8604
            model!!.purposeID = 2
            model!!.currencyID = 1
            model!!.priceBudget = 1000000.23
            model!!.landArea = java.lang.Double.parseDouble(txtLandArea.text.toString())
            model!!.landAreaUnitID = 1
            model!!.privacy = 1
            model!!.isActive = false
            model!!.isHot = true
            model!!.isFeatured = true
            model!!.isPromo = true
            model!!.isPopOut = true
            model!!.subscriberID = 1
            model!!.createdBy = 1
            model!!.description = txtDescription.text.toString()
            obj = ManagerPropertyTask()
            obj!!.execute()
        }
    }

    private fun GetAsync() {
        when (count) {
            1 -> {
                URL = "http://rehajomobileapi.hundredalpha.com/api/Properties/GETCityLookup"
                key = "CityName"
                getData = spCity?.let { GetData(URL!!, it) }
                getData!!.execute()
            }
            2 -> {
                URL = "http://rehajomobileapi.hundredalpha.com/api/Properties/GETPropCategoriesLookup"
                key = "PropertyCategName"
                getData = spPropertyType?.let { GetData(URL!!, it) }
                getData!!.execute()
            }
            3 -> {
                URL = "http://rehajomobileapi.hundredalpha.com/api/Properties/GETUnitLookup"
                key = "UnitName"
                getData = spAreaUnit?.let { GetData(URL!!, it) }
                getData!!.execute()
            }
            4 -> {
                URL = "http://rehajomobileapi.hundredalpha.com/api/Properties/GETCurrencyLookup"
                key = "CurrencyName"
                getData = spCurrency?.let { GetData(URL!!, it) }
                getData!!.execute()
            }
            5 -> {
                URL = "http://rehajomobileapi.hundredalpha.com/api/Properties/GETPurposeLookup"
                key = "PurposeName"
                getData = spPurpose?.let { GetData(URL!!, it) }
                getData!!.execute()
            }
            6 -> {

                URL = "http://rehajomobileapi.hundredalpha.com/api/Properties/GETPropertyPrivacyLookUp"
                key = "Privacy"
                getData = spPrivacy?.let { GetData(URL!!, it) }
                getData!!.execute()
            }
            7 -> {
                URL = "http://rehajomobileapi.hundredalpha.com/api/Properties/GETPropertyStatusLookUp"
                key = "Status"
                getData = spStatus?.let { GetData(URL!!, it) }
                getData!!.execute()
            }
        }
    }

    inner class ManagerPropertyTask : AsyncTask<Void, Void, String>() {
        override fun onPreExecute() {
            super.onPreExecute()
            pd = ProgressDialog(this@ManagePropertyMasterActivity)
            pd.isIndeterminate = false
            pd.setTitle("Please wait")
            pd.setMessage("Loading...")
            pd.show()
        }

        override fun onPostExecute(s: String) {
            super.onPostExecute(s)
            pd.hide()
            Toast.makeText(this@ManagePropertyMasterActivity, s, Toast.LENGTH_LONG).show()
        }

        override fun doInBackground(vararg voids: Void): String {
            val map = HashMap<String, Any>()
            map["Title"] = model!!.title
            map["PropertyCategoryID"] = model!!.propertyCategoryID
            map["CityID"] = model!!.cityID
            map["streetName"] = model!!.streetRoadName
            map["Address"] = model!!.address
            map["LocationAlias"] = model!!.locationAlias
            map["Address_Component"] = model!!.address_Component
            map["SubLocalityLevel"] = model!!.subLocalityLevel
            map["Latitude"] = model!!.latitude
            map["Longitude"] = model!!.longitude
            map["PurposeID"] = model!!.purposeID
            map["CurrencyID"] = model!!.currencyID
            map["PriceBudget"] = model!!.priceBudget
            map["LandArea"] = model!!.landArea
            map["UnitID"] = model!!.landAreaUnitID
            map["Privacy"] = model!!.privacy
            map["Active"] = model!!.Active
            map["IsHot"] = 1
            map["IsFeatured"] = 1
            map["IsPromo"] = 1
            map["IsPopOut"] = 1
            map["SubscriberID"] = 1
            map["CreatedBy"] = 1
            map["Description"] = model!!.description

            val url = "http://rehajomobileapi.hundredalpha.com/api/ManageProperty/POSTaddpropertyintodatabase"
            return Parser.Post(url, map)
        }
    }

    inner class GetData(url: String, sp: Spinner) : AsyncTask<Void, Void, String>() {

        init {
            spinner = sp
            URL = url
        }

        override fun onPreExecute() {
            super.onPreExecute()
        }

        override fun onPostExecute(response: String) {
            super.onPostExecute(response)
            FillDropDownData(response, key, spinner)
        }

        override fun doInBackground(vararg voids: Void): String? {
            return Parser.Get(URL)
            //            String url = "http://rehajomobileapi.hundredalpha.com/api/Properties/GETCityLookup";
            //            String response = Parser.Get(url);
            //            FillCity(response);
            //            url = "http://rehajomobileapi.hundredalpha.com/api/Properties/GETPropCategoriesLookup";
            //            response = Parser.Get(url);
            //            FillPropertyType(response);
            //            url = "http://rehajomobileapi.hundredalpha.com/api/Properties/GETCurrencyLookup";
            //            response = Parser.Get(url);
            //            FillCurrency(response);
            //            return "Success";
        }
    }

    fun FillDropDownData(response: String, key: String?, sp: Spinner?) {
        val list = ArrayList<String>()
        val jsonObject: JSONObject? = null
        try {

            val jsonArray = JSONArray(response)
            for (i in 0 until jsonArray.length()) {
                val `object` = jsonArray.getJSONObject(i)
                list.add(`object`.getString(key))
            }
        } catch (e: JSONException) {
            e.printStackTrace()
        }

        PopulateSpinner(list, sp!!)
    }

    private fun PopulateSpinner(content: ArrayList<String>, sp: Spinner) {
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, content)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        sp.adapter = adapter
        count += 1
        GetAsync()
    }

}


