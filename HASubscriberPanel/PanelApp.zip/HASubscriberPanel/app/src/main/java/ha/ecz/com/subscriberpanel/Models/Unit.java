package ha.ecz.com.subscriberpanel.Models;

public class Unit {

    public int UnitID;
    public String UnitName;
    public String ShortCode;
    public boolean isDefault;

}
