package ha.ecz.com.subscriberpanel.Models;

public class PropertyCategory {
    public int PropertyCategoryID;
    public String PropertyCategName;
    public String IconCode;
    public boolean Active;
    public boolean IsDefault;

    public PropertyCategory(int propCategID, String propCategName)
    {
        PropertyCategoryID = propCategID;
        PropertyCategName = propCategName;
    }
}
