package ha.ecz.com.subscriberpanel.RetroService.Response

data class Data(
        val id: Int
)