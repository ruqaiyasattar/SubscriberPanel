package ha.ecz.com.subscriberpanel.RetroService.Requests

data class spinData(
        val key_Activ: Int,
        val value_Activ: String

)