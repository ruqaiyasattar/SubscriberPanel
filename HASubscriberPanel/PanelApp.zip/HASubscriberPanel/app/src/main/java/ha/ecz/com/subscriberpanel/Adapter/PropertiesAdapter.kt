package ha.ecz.com.subscriberpanel.Adapter

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView


import ha.ecz.com.subscriberpanel.Models.Property
import ha.ecz.com.subscriberpanel.R

class PropertiesAdapter(private val _propsData: Array<Property>) : RecyclerView.Adapter<PropertiesAdapter.PropertiesViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PropertiesViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.property_listitem, parent, false)
        return PropertiesViewHolder(view)
    }

    override fun onBindViewHolder(holder: PropertiesViewHolder, position: Int) {
        var objProp = _propsData[position]
        holder._txtPropTitle.text = objProp.Title
        holder._txtLocation.text = objProp.StreetRoadName
        holder._txtPrice.text = java.lang.Double.toString(objProp.PriceBudget)
        holder._txtArea.text = java.lang.Double.toString(objProp.LandArea)
       // holder._imgProp!!.setImageDrawable( objProp.ImageURL)

    }

    override fun getItemCount(): Int {
        return _propsData.size
    }

    inner class PropertiesViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        val _imgProp: ImageView?
        val _txtPropTitle: TextView
        val _txtLocation: TextView
        val _txtPrice: TextView
        val _txtArea: TextView

        init {
            //_imgProp
            _txtPropTitle = itemView.findViewById<View>(R.id.txtPropTitle) as TextView
            _txtLocation = itemView.findViewById<View>(R.id.txtLocation) as TextView
            _txtPrice = itemView.findViewById<View>(R.id.txtPrice) as TextView
            _txtArea = itemView.findViewById<View>(R.id.txtArea) as TextView
            _imgProp = itemView.findViewById<View>(R.id.imgProperty) as ImageView
        }
    }

}
