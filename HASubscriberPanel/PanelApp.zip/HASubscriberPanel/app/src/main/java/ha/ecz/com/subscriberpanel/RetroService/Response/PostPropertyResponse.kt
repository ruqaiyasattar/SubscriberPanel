package ha.ecz.com.subscriberpanel.RetroService.Response

data class PostPropertyResponse(
        val data: Data,
        val message: String,
        val status: Boolean
)