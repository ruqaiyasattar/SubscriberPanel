package ha.ecz.com.subscriberpanel.Adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;


import ha.ecz.com.subscriberpanel.Models.ManageProperty;
import ha.ecz.com.subscriberpanel.R;

/*public class PropertyAdapter extends RecyclerView.Adapter<PropertiesAdapter.PropertiesViewHolder> {
    private ManageProperty[] _propsData;*/

//    public  PropertyAdapter(ManageProperty[] propData){
//        this._propsData = propData;
//    }
//
//    @NonNull
//    @Override
//    public ManagerPropertyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
//        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.property_listitem,parent,false);
//        return new ManagerPropertyViewHolder(view);
//    }
//
//    @Override
//    public void onBindViewHolder(@NonNull PropertiesAdapter.PropertiesViewHolder propertiesViewHolder, int i) {
//
//    }
//
//    @Override
//    public void onBindViewHolder(@NonNull ManagerPropertyViewHolder holder, int position) {
//        ManageProperty objProp = _propsData[position];
//        holder._txtPropTitle.setText(objProp.Title);
//        holder._txtLocation.setText(objProp.StreetRoadName);
//        holder._txtPrice.setText(Double.toString(objProp.PriceBudget));
//        holder._txtArea.setText(Double.toString(objProp.LandArea));
//    }
//
//    @Override
//    public int getItemCount() {
//        return _propsData.length;
//    }
//
//    public class ManagerPropertyViewHolder extends RecyclerView.ViewHolder{
//
//        private ImageView _imgProp;
//        private TextView _txtPropTitle, _txtLocation, _txtPrice, _txtArea;
//        public ManagerPropertyViewHolder(@NonNull View itemView) {
//            super(itemView);
//            //_imgProp
//            _txtPropTitle = (TextView) itemView.findViewById(R.id.txtPropTitle);
//            _txtLocation = (TextView) itemView.findViewById(R.id.txtLocation);
//            _txtPrice = (TextView) itemView.findViewById(R.id.txtPrice);
//            _txtArea = (TextView) itemView.findViewById(R.id.txtArea);
//        }
//    }

//}
