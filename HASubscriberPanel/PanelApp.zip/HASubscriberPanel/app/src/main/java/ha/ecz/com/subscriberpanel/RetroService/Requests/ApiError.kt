package ha.ecz.com.subscriberpanel.RetroService.Requests

import com.google.gson.JsonParser
import retrofit2.HttpException
import retrofit2.Response

class ApiError (error: Response<String>) {
    var message = "An error occurred"

    init {
        if (error is HttpException) {
            val errorJsonString = error.response()
                    .errorBody()?.string()
            this.message = JsonParser().parse(errorJsonString)
                    .asJsonObject["message"]
                    .asString
        } else {
         //   this.message = error.message ?: this.message
        }
    }
}