package ha.ecz.com.subscriberpanel.Models;

public class Currency {

    public int CurrencyID;
    public String CurrencyName;
    public double Rate;
    public String Symbol;
    public boolean isDefault;

}
