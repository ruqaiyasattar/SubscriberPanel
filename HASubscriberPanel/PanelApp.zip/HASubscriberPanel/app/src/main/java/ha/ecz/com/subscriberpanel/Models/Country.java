package ha.ecz.com.subscriberpanel.Models;

public class Country {
    public int CountryID;
    public String CountryName;
    public String PACCSCode;
}
