@file:Suppress("DEPRECATION")

package ha.ecz.com.subscriberpanel

import android.Manifest
import android.Manifest.permission
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.IntentSender
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.location.Location
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.support.v4.app.ActivityCompat
import android.support.v7.app.ActionBar
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.*
import android.widget.AdapterView
import com.android.volley.Request
import com.bumptech.glide.Glide
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.api.GoogleApiClient
import com.google.android.gms.common.api.ResultCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.LocationSettingsRequest
import com.google.android.gms.location.LocationSettingsStatusCodes
import com.google.android.gms.location.places.PlaceBuffer
import com.google.android.gms.location.places.Places
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.MapFragment
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.model.LatLng
import com.google.android.libraries.places.internal.i
import com.google.gson.Gson
import ha.ecz.com.subscriberpanel.BSImagePicker.BSImagePicker
import ha.ecz.com.subscriberpanel.Models.*
import ha.ecz.com.subscriberpanel.Models.Unit
import ha.ecz.com.subscriberpanel.RESTService.CVStringResp
import ha.ecz.com.subscriberpanel.RESTService.VolleyStrCallback
import ha.ecz.com.subscriberpanel.RetroService.Requests.APIService
import ha.ecz.com.subscriberpanel.RetroService.Requests.AddPropertyRequest
import ha.ecz.com.subscriberpanel.RetroService.Requests.ApiError
import ha.ecz.com.subscriberpanel.RetroService.Requests.ApiUtils
import ha.ecz.com.subscriberpanel.Utils.ImageUtil
import ha.ecz.com.subscriberpanel.Utils.checkSelfPermissionCompat
import ha.ecz.com.subscriberpanel.Utils.shouldShowRequestPermissionRationaleCompat
import kotlinx.android.synthetic.main.activity_manageproperty.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.HashMap
import kotlin.collections.ArrayList
import kotlin.collections.set

@Suppress("UNREACHABLE_CODE", "NAME_SHADOWING")

class ManagePropertyActivity : AppCompatActivity(),
        GoogleApiClient.OnConnectionFailedListener, AdapterView.OnItemSelectedListener,
        GoogleApiClient.ConnectionCallbacks, ResultCallback<PlaceBuffer>, OnMapReadyCallback, BSImagePicker.OnSingleImageSelectedListener,
        BSImagePicker.OnMultiImageSelectedListener, ActivityCompat.OnRequestPermissionsResultCallback {

    //variables
    //multiple images
    internal lateinit var apiService: APIService
    private var ivImage1: ImageView? = null;
    private var ivImage2: ImageView? = null;
    private var ivImage3: ImageView? = null;
    private var ivImage4: ImageView? = null;
    private var ivImage5: ImageView? = null;
    private var ivImage6: ImageView? = null;
    //


    //googlemap
    private val REQUEST_CHECK_SETTINGS = 1000
    private var mapFragment: MapFragment? = null
    private var mMap: GoogleMap? = null
    private var googleApiClient: GoogleApiClient? = null
    private var mLastLocation: Location? = null
    private var request: LocationRequest? = null
    internal var mapView: View? = null
    private var locationTextView: AutoCompleteTextView? = null
    private var mRequestingLocationUpdates: Boolean = false

    //for mutliple img
    var PICK_IMAGE_MULTIPLE = 1000
    lateinit var imageEncoded: String
    lateinit var imagesEncodedList: List<String>
    //end here

    private var _appContext: Context? = null
    private var _imgMenubutton: ImageView? = null// Actionbar
    private val _gallery = 1
    private val _camera = 2
    private val _cmbAA: ArrayAdapter<*>? = null
    private val _objGSON = Gson()
    private val _objRR = CVStringResp()
    private var _cmbPropertyType: Spinner? = null
    private var _cmbCity: Spinner? = null
    private var _cmbPurpose: Spinner? = null
    private var _cmbCurrency: Spinner? = null
    private var _cmbAreaUnit: Spinner? = null
    private var _propCategs: Array<PropertyCategory>? = null
    private var _propCity: Array<City>? = null
    private var _propPurpose: Array<Purpose>? = null
    private var _propCurrency: Array<Currency>? = null
    private var _propUnit: Array<Unit>? = null
    var PICK_IMAGE_SINGLE = 2;
    var ONREQUEST_PER1 = 0
    var ONREQUEST_PER2 = 1002


    private var _objContext: Context? = null


    override fun onNothingSelected(parent: AdapterView<*>?) {
        TODO("not implemented")
        //To change body of created functions use File | Settings | File Templates.
    }

    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
        TODO("not implemented")
        //To change body of created functions use File | Settings | File Templates.
    }

    override fun onResult(p0: PlaceBuffer) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        setContentView(R.layout.activity_manageproperty)



        locationTextView = findViewById<AutoCompleteTextView>(R.id.location_text)

        //multiselect
        ivImage1 = findViewById<ImageView>(R.id.iv_image1)
        ivImage2 = findViewById<ImageView>(R.id.iv_image2)
        ivImage3 = findViewById<ImageView>(R.id.iv_image3)
        ivImage4 = findViewById<ImageView>(R.id.iv_image4)
        ivImage5 = findViewById<ImageView>(R.id.iv_image5)
        ivImage6 = findViewById<ImageView>(R.id.iv_image6)

        //val txtPropertyTitle = findViewById<View>(R.id.txtPropertyTitle) as EditText
        _cmbPropertyType = findViewById<View>(R.id.cmbPropertyType) as Spinner
        _cmbCity = findViewById<View>(R.id.cmbCity) as Spinner
        _cmbPurpose = findViewById<View>(R.id.cmbPurpose) as Spinner
        _cmbCurrency = findViewById<View>(R.id.cmbCurrency) as Spinner
        _cmbAreaUnit = findViewById<View>(R.id.cmbAreaUnit) as Spinner


        val txtTitle = findViewById<View>(R.id.txtPropertyTitle) as EditText
        val txtPropLocation = findViewById<View>(R.id.location_text) as EditText
        val txtPrice = findViewById<View>(R.id.txtPrice) as EditText
        val txtLandArea = findViewById<View>(R.id.txtLandArea) as EditText
        val txtPropAddress = findViewById<View>(R.id.txtPropAddress) as EditText
        val txtDescription = findViewById<View>(R.id.txtDescription) as EditText

        val spinPropType = findViewById<View>(R.id.cmbPropertyType) as Spinner
        val spinPurpose = findViewById<View>(R.id.cmbPurpose) as Spinner
        val spinCurrncy = findViewById<View>(R.id.cmbCurrency) as Spinner
        val spinReaUnit = findViewById<View>(R.id.cmbAreaUnit) as Spinner
        val spinPrivacy = findViewById<View>(R.id.cmbPrivacy) as Spinner
        val spinActive = findViewById<View>(R.id.cmbActive) as Spinner

        val CmdCity = findViewById<View>(R.id.cmbCity) as Spinner

        _appContext = applicationContext

        apiService = ApiUtils.getApiService()

        val imgFrontPhoto = findViewById<View>(R.id.imgFrontPhoto) as ImageView
        imgFrontPhoto.setOnClickListener {

            //showPictureDialog()

            //mine code for img
            val intent = Intent(Intent.ACTION_PICK,
                    MediaStore.Images.Media.INTERNAL_CONTENT_URI)
            intent.type = "image/*"
            intent.putExtra("crop", "true")
            intent.putExtra("scale", true)
            intent.putExtra("outputX", 256)
            intent.putExtra("outputY", 256)
            intent.putExtra("aspectX", 1)
            intent.putExtra("aspectY", 1)
            intent.putExtra("return-data", true)
            startActivityForResult(intent, PICK_IMAGE_SINGLE)

        }

        btn_multi_selection.setOnClickListener {
            val pickerDialog = BSImagePicker.Builder("com.asksira.imagepickersheetdemo.fileprovider")
                    .setMaximumDisplayingImages(Integer.MAX_VALUE)
                    .setMinimumMultiSelectCount(3)
                    .setMaximumMultiSelectCount(6)
                    .build()
            pickerDialog.show(supportFragmentManager, "picker")
        }
        //end multiselect

        //submit data to server
        submit_data.setOnClickListener {

            //this is submit button
            val params = HashMap<String, String>()
            var Title = location_text.getText().toString()
            var Address_Component = location_text.getText().toString()
            var LocationAlias = location_text.getText().toString()
            var streetName = location_text.getText().toString()
            var PriceBudget = txtPrice.getText().toString()
            var LandArea = txtLandArea.getText().toString()
            var Address = txtPropAddress.getText().toString()
            var streetName1 = txtPropAddress.getText().toString()
            var CityID = CmdCity.getSelectedItem().toString()
            var Description = txtDescription.getText().toString()

            var PropertyCategoryID = cmbPropertyType.getSelectedItem().toString()
            var PurposeID = cmbPurpose.getSelectedItem().toString()

            var CurrencyID = cmbCurrency.getSelectedItem().toString()
            var UnitID: Int = cmbAreaUnit.getSelectedItem() as Int
            var Privacy = cmbPrivacy.getSelectedItem().toString()
            var Active = cmbActive.getSelectedItem() as Int

            var clientId: String = intent.getStringExtra("userId")
            var subId = intent.getStringExtra("subId")

            params["SubscriberID"] = subId
            params["CreatedBy"] = clientId

            val userObj = AddPropertyRequest(Active, Address, Address_Component, CityID, clientId, CurrencyID, Description, LandArea,
                    PriceBudget, Privacy, PropertyCategoryID, PurposeID, subId, Title, UnitID, streetName)


            apiService.postProperty(userObj).enqueue(object : Callback<String> {
                var message = "An error occurred"
                override fun onResponse(call: Call<String>, response: Response<String>) {
                    //showJsonResponse.setText(response.body()!!.toString())
                    Log.e("Test",response.toString()+"test");
                    Log.e("TAG", "onResponse ${response.isSuccessful}")
                    Log.e("TEST", "onResponse ${response.errorBody()}")

                    Log.e("TAG", "onResponse ${response.body()}")
                    Log.e("TAG", "onResponse ${response.code()}")
                    Log.e("TAG", "onResponse ${response.code()}")
                    if (response != null) {
                        val errorMessage = ApiError(response).message

                        Log.e("TAG", "onResponse ${errorMessage}")
                    } else {
                        // TODO: Do other things
                    }
                }

                override fun onFailure(call: Call<String>, t: Throwable) {
                    Toast.makeText(this@ManagePropertyActivity, "Error: " + t.message, Toast.LENGTH_SHORT).show()
                    Log.e("TAG", "onFailure ${t.message}")
                    Log.e("TAG", "onFailure ${t.cause}")
                    Log.e("TAG", "onFailure ${t.localizedMessage}")
                }
            })

            //Toast.makeText(applicationContext,clientId,Toast.LENGTH_LONG).show()
            params["SubscriberID"] = subId
            params["CreatedBy"] = clientId

        }

        mapFragment = fragmentManager
                .findFragmentById(R.id.map) as MapFragment
        mapView = mapFragment!!.getView()
        mapFragment!!.getMapAsync(this)

        CheckMapPermission()
        SetCustomActionBar()
        FillPropTypeCombo()
        FillCityCombo()
        FillPurposeCombo()
        FillCurrencyCombo()
        FillUnitCombo()
        addActiveSpinner()
        addPrivacySpinner()
    }

    fun addActiveSpinner() {

        val spin = ArrayList<String>()

        spin.add("InActive")
        spin.add("On Your Website")
        spin.add("On JagahOnline & Your Website")

        var dataAdapter = ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, spin);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //cmbActive.setAdapter(dataAdapter);

        var selectionPosition= dataAdapter.getPosition(spin.toString());
        cmbActive.setSelection(selectionPosition);
        cmbActive.setAdapter(dataAdapter);
    }

    fun addPrivacySpinner() {
        val list = ArrayList<String>()
        list.add("Public")
        list.add("Only For Me")
        var dataAdapter = ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        cmbPrivacy.setAdapter(dataAdapter);
    }

    private fun showCameraPreview() {
        // Check if the Camera permission has been granted
        if (checkSelfPermissionCompat(Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED) {

        } else {
            // Permission is missing and must be requested.
            requestCameraPermission()
        }
    }

    /**
     * Requests the [android.Manifest.permission.CAMERA] permission.
     * If an additional rationale should be displayed, the user has to launch the request from
     * a SnackBar that includes additional information.
     */
    private fun requestCameraPermission() {
        // Permission has not been granted and must be requested.
        if (shouldShowRequestPermissionRationaleCompat(Manifest.permission.CAMERA)) {


        } else {
        }
    }

    //img lib atart
    override fun onSingleImageSelected(uri: Uri, tag: String) {
        Glide.with(this@ManagePropertyActivity).load(uri).into(ivImage2!!)
    }

    override fun onMultiImageSelected(uriList: List<Uri>, tag: String) {
        for (i in uriList.indices) {
            if (i >= 6) return
            val iv: ImageView
            when (i) {
                0 -> iv = ivImage1!!
                1 -> iv = ivImage2!!
                2 -> iv = ivImage3!!
                3 -> iv = ivImage4!!
                4 -> iv = ivImage5!!
                5 -> iv = ivImage6!!
                else -> iv = ivImage6!!
            }
            Glide.with(this).load(uriList[i]).into(iv)
        }
    }
    //for image lib

    override fun onMapReady(googleMap: GoogleMap) {

        mMap = googleMap


        if (ActivityCompat.checkSelfPermission(this, permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then over   riding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return
        }

        //This line will show your current location on Map with GPS dot
        mMap!!.isMyLocationEnabled = true
        val locationButton = (mapView!!.findViewById<View>(Integer.parseInt("1")).parent as View).findViewById<View>(Integer.parseInt("2"))
        val rlp = locationButton.layoutParams as RelativeLayout.LayoutParams
        // position on right bottom
        rlp.addRule(RelativeLayout.ALIGN_PARENT_TOP, 0)
        rlp.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM, RelativeLayout.TRUE)
        rlp.setMargins(0, 0, 50, 50)

        mMap!!.setOnMyLocationButtonClickListener(GoogleMap.OnMyLocationButtonClickListener {
            locationTextView!!.hint = "Enter Location"
            locationTextView!!.isFocusableInTouchMode = false
            locationTextView!!.isFocusable = false
            locationTextView!!.isFocusableInTouchMode = true
            locationTextView!!.isFocusable = true
            false
        })
    }

    override fun onConnected(bundle: Bundle?) {

    }

    override fun onConnectionSuspended(i: Int) {

    }

    override fun onConnectionFailed(connectionResult: ConnectionResult) {

    }

    fun onLocationChanged(location: Location) {

    }

    private fun setupLocationManager() {
        //buildGoogleApiClient();
        if (googleApiClient == null) {

            googleApiClient = GoogleApiClient.Builder(this)
                    .addConnectionCallbacks(this)
                    .addOnConnectionFailedListener(this)
                    .addApi(LocationServices.API)
                    .addApi(Places.GEO_DATA_API)
                    .addApi(Places.PLACE_DETECTION_API)
                    .build()
            //mGoogleApiClient = new GoogleApiClient.Builder(this);
        }
        googleApiClient!!.connect()
        createLocationRequest()
    }

    protected fun createLocationRequest() {

        request = LocationRequest()
        request!!.smallestDisplacement = 10f
        request!!.fastestInterval = 50000
        request!!.priority = LocationRequest.PRIORITY_HIGH_ACCURACY
        request!!.numUpdates = 10

        val builder = LocationSettingsRequest.Builder()
                .addLocationRequest(request!!)
        builder.setAlwaysShow(true)

        val result = LocationServices.SettingsApi.checkLocationSettings(googleApiClient,
                builder.build())


        result.setResultCallback { result ->
            val status = result.status
            when (status.statusCode) {

                LocationSettingsStatusCodes.SUCCESS -> setInitialLocation()

                LocationSettingsStatusCodes.RESOLUTION_REQUIRED ->
                    // Location settings are not satisfied, but this can be fixed
                    // by showing the user a dialog.
                    try {
                        // Show the dialog by calling startResolutionForResult(),
                        // and check the result in onActivityResult().
                        status.startResolutionForResult(
                                this@ManagePropertyActivity,
                                REQUEST_CHECK_SETTINGS)
                    } catch (e: IntentSender.SendIntentException) {
                        // Ignore the error.
                    }

                LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE -> {
                }
            }// Location settings are not satisfied. However, we have no way
            // to fix the settings so we won't show the dialog.
        }


    }

    private fun setInitialLocation() {


        if (ActivityCompat.checkSelfPermission(applicationContext, permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this@ManagePropertyActivity, permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return
        }
        LocationServices.FusedLocationApi.requestLocationUpdates(googleApiClient, request) { location ->
            mLastLocation = location

            try {
                val positionUpdate = LatLng(location.latitude, location.longitude)
                val update = CameraUpdateFactory.newLatLngZoom(positionUpdate, 15f)
                mMap!!.animateCamera(update)

                val adapter = GooglePlacesAutocompleteAdapter(applicationContext, R.layout.autocompletelistitem)
                locationTextView!!.setAdapter(adapter)

                locationTextView!!.onItemClickListener = AdapterView.OnItemClickListener { adapterView, view, i, l ->
                    val `in` = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                    `in`.hideSoftInputFromWindow(view.applicationWindowToken, 0)
                    val str = adapterView.getItemAtPosition(i) as String
                    val places = str.split("@".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
                    val place_id = places[1]

                    locationTextView!!.setText("")
                    locationTextView!!.hint = places[0]
                    //getLatLng Method is not built-in method, find this method below
                    getLatLang(place_id)
                }

            } catch (ex: Exception) {

                ex.printStackTrace()
                Log.e("MapException", ex.message)

            }
        }
    }

    private fun CheckMapPermission() {

        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP) {

            if (ActivityCompat.checkSelfPermission(applicationContext, permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this@ManagePropertyActivity, permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this@ManagePropertyActivity, arrayOf(permission.ACCESS_FINE_LOCATION, permission.ACCESS_COARSE_LOCATION), 1002)
            } else {

                setupLocationManager()
            }
        } else {
            setupLocationManager()
        }

    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        // If request is cancelled, the result arrays are empty.
        when (requestCode) {

            ONREQUEST_PER1 -> if (requestCode == Companion.PERMISSION_REQUEST_CAMERA) {
                // Request for camera permission.
                if (grantResults.size == 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                } else {
                    // Permission request was denied.
                    //layout.showSnackbar(R.string.camera_permission_denied, Snackbar.LENGTH_SHORT)
                }
            }
            ONREQUEST_PER2 -> if (grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                if (ActivityCompat.checkSelfPermission(this, permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this,
                                permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {

                    setupLocationManager()

                }
            } else {

                Toast.makeText(this@ManagePropertyActivity, "Permission Denied", Toast.LENGTH_SHORT).show()
                //finish();
            }
        }
    }

    //lang and lat
    fun getLatLang(placeId: String) {
        this.googleApiClient?.let {
            Places.GeoDataApi.getPlaceById(it, placeId)
                    .setResultCallback { places ->
                        if (places.status.isSuccess && places.count > 0) {
                            val place = places.get(0)
                            val latLng = place.latLng

                            Toast.makeText(this, latLng.toString(), Toast.LENGTH_LONG).show()

                            try {

                                val update = CameraUpdateFactory.newLatLngZoom(latLng, 15f)
                                mMap!!.animateCamera(update)
                            } catch (ex: Exception) {

                                ex.printStackTrace()
                                Log.e("MapException", ex.message)

                            }

                            Log.i("place", "Place found: " + place.name)
                        } else {
                            Log.e("place", "Place not found")
                        }
                        places.release()
                    }
        }
    }

    private fun FillPropTypeCombo() {
        _objRR.STRINGReqResp(applicationContext, Request.Method.GET,
                "Properties/GETPropCategoriesLookup", object : VolleyStrCallback {
            @Throws(Exception::class)
            override fun onSuccess(result: String?) {
                if (result != null) {
                    if (result.length > 0 && result !== "[]") {

                        _propCategs = _objGSON.fromJson<Array<PropertyCategory>>(result, Array<PropertyCategory>::class.java)
                        val propCategs = arrayOfNulls<String>(_propCategs!!.size + 1)
                        for (i in 0.._propCategs!!.size) {
                            propCategs[i] = if (i == 0) " -Select Type- " else _propCategs!![i - 1].PropertyCategName
                        }

                        val adPC = ArrayAdapter(_appContext!!, android.R.layout.simple_spinner_item, propCategs)
                        adPC.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                        _cmbPropertyType!!.adapter = adPC
                    }
                }
            }

            @Throws(Exception::class)
            override fun onError(result: String) {
                Log.e("Err From Out Call", result)
                Toast.makeText(_appContext, result, Toast.LENGTH_SHORT).show()
            }
        }, null)
    }

    private fun FillCityCombo() {
        _objRR.STRINGReqResp(applicationContext, Request.Method.GET,
                "Properties/GETCityLookup", object : VolleyStrCallback {
            @Throws(Exception::class)
            override fun onSuccess(result: String?) {
                if (result != null) {
                    if (result.length > 0 && result !== "[]") {

                        _propCity = _objGSON.fromJson<Array<City>>(result, Array<City>::class.java)
                        val propCity = arrayOfNulls<String>(_propCity!!.size + 1)
                        for (i in 0.._propCity!!.size) {
                            propCity[i] = if (i == 0) " -Select City- " else _propCity!![i - 1].CityName
                        }

                        val adPC = ArrayAdapter(_appContext!!, android.R.layout.simple_spinner_item, propCity)
                        adPC.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                        _cmbCity!!.adapter = adPC
                    }
                }
            }

            @Throws(Exception::class)
            override fun onError(result: String) {
                Log.e("Err From Out Call", result)
                Toast.makeText(_appContext, result, Toast.LENGTH_SHORT).show()
            }
        }, null)
    }

    private fun FillPurposeCombo() {
        _objRR.STRINGReqResp(applicationContext, Request.Method.GET,
                "Properties/GETPurposeLookup", object : VolleyStrCallback {
            @Throws(Exception::class)
            override fun onSuccess(result: String?) {
                if (result != null) {
                    if (result.length > 0 && result !== "[]") {

                        _propPurpose = _objGSON.fromJson<Array<Purpose>>(result, Array<Purpose>::class.java)
                        val propPurpose = arrayOfNulls<String>(_propPurpose!!.size)
                        for (i in _propPurpose!!.indices) {
                            propPurpose[i] = _propPurpose!![i].PurposeName
                        }

                        val adPP = ArrayAdapter(_appContext!!, android.R.layout.simple_spinner_item, propPurpose)
                        adPP.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                        _cmbPurpose!!.adapter = adPP
                    }
                }
            }

            @Throws(Exception::class)
            override fun onError(result: String) {
                Log.e("Err From Out Call", result)
                Toast.makeText(_appContext, result, Toast.LENGTH_SHORT).show()
            }
        }, null)
    }

    private fun FillCurrencyCombo() {
        _objRR.STRINGReqResp(applicationContext, Request.Method.GET,
                "Properties/GETCurrencyLookup", object : VolleyStrCallback {
            @Throws(Exception::class)
            override fun onSuccess(result: String?) {
                if (result != null) {
                    if (result.length > 0 && result !== "[]") {
                        _propCurrency = _objGSON.fromJson<Array<Currency>>(result, Array<Currency>::class.java)
                        val propCurr = arrayOfNulls<String>(_propCurrency!!.size)
                        for (i in _propCurrency!!.indices) {
                            propCurr[i] = _propCurrency!![i].CurrencyName
                        }

                        val adPP = ArrayAdapter(_appContext!!, android.R.layout.simple_spinner_item, propCurr)
                        adPP.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                        _cmbCurrency!!.adapter = adPP
                    }
                }
            }

            @Throws(Exception::class)
            override fun onError(result: String) {
                Log.e("Err From Out Call", result)
                Toast.makeText(_appContext, result, Toast.LENGTH_SHORT).show()
            }
        }, null)
    }

    private fun FillUnitCombo() {
        _objRR.STRINGReqResp(applicationContext, Request.Method.GET,
                "Properties/GETUnitLookup", object : VolleyStrCallback {
            @Throws(Exception::class)
            override fun onSuccess(result: String?) {
                if (result != null) {
                    if (result.length > 0 && result !== "[]") {

                        _propUnit = _objGSON.fromJson<Array<Unit>>(result, Array<Unit>::class.java)
                        val propUnit = arrayOfNulls<String>(_propUnit!!.size)
                        for (i in _propUnit!!.indices) {
                            propUnit[i] = _propUnit!![i].UnitName
                        }

                        val adPU = ArrayAdapter(_appContext!!, android.R.layout.simple_spinner_item, propUnit)
                        adPU.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                        _cmbAreaUnit!!.adapter = adPU
                    }
                }
            }

            @Throws(Exception::class)
            override fun onError(result: String) {
                Log.e("Err From Out Call", result)
                Toast.makeText(_appContext, result, Toast.LENGTH_SHORT).show()
            }
        }, null)
    }

    //mine code for selecting img
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {

        when (requestCode) {
            //for multiple images selection
            //BAD practice... Declare it constant khn
            PICK_IMAGE_MULTIPLE -> {
                when (resultCode) {

                    Activity.RESULT_OK -> {
                        setInitialLocation()
                        Toast.makeText(this@ManagePropertyActivity, "Location enabled by user!", Toast.LENGTH_LONG).show()
                        mRequestingLocationUpdates = true
                    }
                    Activity.RESULT_CANCELED -> {

                        // The user was asked to change settings, but chose not to
                        Toast.makeText(this@ManagePropertyActivity, "Location not enabled, user cancelled.", Toast.LENGTH_LONG).show()
                        mRequestingLocationUpdates = false

                    }
                }

            }
            //end here for google map

            //for single image seleciton
            PICK_IMAGE_SINGLE -> {
                when (resultCode) {
                    Activity.RESULT_OK -> {
                        if (data != null) {

                            val extras = data.extras
                            if (extras != null) {
                                //Get image
                                val newProfilePic = extras.getParcelable<Bitmap>("data")
                                var newBitmap = newProfilePic as Bitmap
                                imgFrontPhoto.setImageBitmap(newBitmap)

                                val base64String: String = ImageUtil.convert(newBitmap)
                                Toast.makeText(applicationContext, base64String.toString(), Toast.LENGTH_LONG).show()
                            }
                        }
                    }
                    Activity.RESULT_CANCELED -> {
                        Toast.makeText(this, "Please capture :(", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    private fun SetCustomActionBar() {
        supportActionBar!!.displayOptions = ActionBar.DISPLAY_SHOW_CUSTOM
        supportActionBar!!.setCustomView(R.layout.custom_action_bar)
        supportActionBar!!.setDisplayShowTitleEnabled(false)
        supportActionBar!!.setDisplayShowCustomEnabled(true)
        supportActionBar!!.setDisplayUseLogoEnabled(false)
        supportActionBar!!.setDisplayShowHomeEnabled(false)
        supportActionBar!!.setBackgroundDrawable(_appContext!!.resources.getDrawable(
                R.drawable.drawable_actionbar_back))
        _imgMenubutton = findViewById<View>(R.id.imgMenu) as ImageView
        _imgMenubutton!!.visibility = View.GONE
    }

    companion object {
        const val PERMISSION_REQUEST_CAMERA = 0
    }

}
