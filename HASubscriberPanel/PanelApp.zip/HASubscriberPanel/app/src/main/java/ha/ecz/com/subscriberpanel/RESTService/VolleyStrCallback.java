package ha.ecz.com.subscriberpanel.RESTService;

public interface VolleyStrCallback {
    void onSuccess(String result) throws Exception;
    void onError(String result) throws Exception;
}
