package ha.ecz.com.subscriberpanel.RetroService.Requests;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;


public interface APIService {

    @GET("posts")
    Call<List<AddPropertyRequest>> getUsers();

    @GET("posts/")
    Call<List<AddPropertyRequest>> getUsers(@Query("id") String userId);

    /*@Headers("content-type:application/json")
    @POST("addpropertyintodatabase")
    Call<String> postUser(@Body String body);*/

// i have not call this
    @POST("POSTaddpropertyintodatabase")
    Call<String> postUser(@Field("Active") String Active,
                          @Field("Address") String Address,
                          @Field("Address_Component") String Address_Component,
                          @Field("CityID") String CityID,
                          @Field("CreatedBy") String CreatedBy,
                          @Field("CurrencyID") String CurrencyID,
                          @Field("Description") String Description,
                          @Field("LandArea") String LandArea,
                          @Field("LocationAlias") String LocationAlias,
                          @Field("PriceBudget") String PriceBudget,
                          @Field("Privacy") String Privacy,
                          @Field("PropertyCategoryID") String PropertyCategoryID,
                          @Field("PurposeID") String PurposeID,
                          //@Field("SubLocalityLevel") String SubLocalityLevel,
                          @Field("SubscriberID") String SubscriberID,
                          @Field("Title") String Title,
                          @Field("UnitID") String UnitID,
                          @Field("streetName") String streetName);

    @POST("POSTaddpropertyintodatabase")
    Call<String> postProperty(@Body AddPropertyRequest propertyRequest);

}
