package ha.ecz.com.subscriberpanel.RetroService.Requests;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.converter.scalars.ScalarsConverterFactory;

/**
 * Created by Farhan on 2/12/2018.
 */

public class ApiUtils {

    //public static final String BASE_URL = "https://jsonplaceholder.typicode.com/";
    private static final String BASE_URL = "http://rehajomobileapi.hundredalpha.com/api/ManageProperty/";

    public static APIService getApiService() {
        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL) //This is the onlt mandatory call on Builder object.
                .client(new OkHttpClient.Builder().addInterceptor(interceptor).build()) //The Htttp client to be used for requests
                .addConverterFactory(GsonConverterFactory.create()) // Convertor library used to convert response into POJO
                .addConverterFactory(ScalarsConverterFactory.create()) // Convertor library used to convert response into POJO
                .build();
        return retrofit.create(APIService.class);
    }
}
