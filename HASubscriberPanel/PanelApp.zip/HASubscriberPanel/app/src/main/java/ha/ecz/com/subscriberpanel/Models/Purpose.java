package ha.ecz.com.subscriberpanel.Models;

public class Purpose {

    public int PurposeID;
    public String PurposeName;
    public String PurposeColor;

}
