package ha.ecz.com.subscriberpanel.RetroService.Requests

data class AddPropertyRequest(
        val Active: Int,
        val Address: String,
        val Address_Component: String,
        val CityID: String,
        val CreatedBy: String,
        val CurrencyID: String,
        val Description: String,
       // val IsFeatured: Int,
       // val IsHot: Int,
       // val IsPopOut: Int,
       // val IsPromo: Int,
        val LandArea: String,
      //  val Latitude: Double,
      //  val LocationAlias: String,
     //   val Longitude: Double,
        val PriceBudget: String,
        val Privacy: String,
        val PropertyCategoryID: String,
        val PurposeID: String,
       // val SubLocalityLevel: String,
        val SubscriberID: String,
        val Title: String,
        val UnitID: Int,
        val streetName: String
)