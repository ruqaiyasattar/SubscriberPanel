package ha.ecz.com.subscriberpanel.Models;

import java.util.Date;

public class ManageProperty {
    public int PropertyID;
    public String Title;
    public String Description;
    public String Address;
    public String StreetRoadName;
    public String DistrictZone;
    public String PostalCode;
    public int CityID;
    public City City;
    public int PropertyCategoryID;

    public int getPropertyID() {
        return PropertyID;
    }

    public void setPropertyID(int propertyID) {
        PropertyID = propertyID;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getStreetRoadName() {
        return StreetRoadName;
    }

    public void setStreetRoadName(String streetRoadName) {
        StreetRoadName = streetRoadName;
    }

    public String getDistrictZone() {
        return DistrictZone;
    }

    public void setDistrictZone(String districtZone) {
        DistrictZone = districtZone;
    }

    public String getPostalCode() {
        return PostalCode;
    }

    public void setPostalCode(String postalCode) {
        PostalCode = postalCode;
    }

    public int getCityID() {
        return CityID;
    }

    public void setCityID(int cityID) {
        CityID = cityID;
    }

    public ha.ecz.com.subscriberpanel.Models.City getCity() {
        return City;
    }

    public void setCity(ha.ecz.com.subscriberpanel.Models.City city) {
        City = city;
    }

    public int getPropertyCategoryID() {
        return PropertyCategoryID;
    }

    public void setPropertyCategoryID(int propertyCategoryID) {
        PropertyCategoryID = propertyCategoryID;
    }

    public ha.ecz.com.subscriberpanel.Models.PropertyCategory getPropertyCategory() {
        return PropertyCategory;
    }

    public void setPropertyCategory(ha.ecz.com.subscriberpanel.Models.PropertyCategory propertyCategory) {
        PropertyCategory = propertyCategory;
    }

    public int getPurposeID() {
        return PurposeID;
    }

    public void setPurposeID(int purposeID) {
        PurposeID = purposeID;
    }

    public ha.ecz.com.subscriberpanel.Models.Purpose getPurpose() {
        return Purpose;
    }

    public void setPurpose(ha.ecz.com.subscriberpanel.Models.Purpose purpose) {
        Purpose = purpose;
    }

    public double getLandArea() {
        return LandArea;
    }

    public void setLandArea(double landArea) {
        LandArea = landArea;
    }

    public int getLandAreaUnitID() {
        return LandAreaUnitID;
    }

    public void setLandAreaUnitID(int landAreaUnitID) {
        LandAreaUnitID = landAreaUnitID;
    }

    public Unit getLandAreaUnit() {
        return LandAreaUnit;
    }

    public void setLandAreaUnit(Unit landAreaUnit) {
        LandAreaUnit = landAreaUnit;
    }

    public double getPriceBudget() {
        return PriceBudget;
    }

    public void setPriceBudget(double priceBudget) {
        PriceBudget = priceBudget;
    }

    public int getCurrencyID() {
        return CurrencyID;
    }

    public void setCurrencyID(int currencyID) {
        CurrencyID = currencyID;
    }

    public ha.ecz.com.subscriberpanel.Models.Currency getCurrency() {
        return Currency;
    }

    public void setCurrency(ha.ecz.com.subscriberpanel.Models.Currency currency) {
        Currency = currency;
    }

    public double getLatitude() {
        return Latitude;
    }

    public void setLatitude(double latitude) {
        Latitude = latitude;
    }

    public double getLongitude() {
        return Longitude;
    }

    public void setLongitude(double longitude) {
        Longitude = longitude;
    }

    public int getPrivacy() {
        return Privacy;
    }

    public void setPrivacy(int privacy) {
        Privacy = privacy;
    }

    public boolean isHot() {
        return IsHot;
    }

    public void setHot(boolean hot) {
        IsHot = hot;
    }

    public boolean isFeatured() {
        return IsFeatured;
    }

    public void setFeatured(boolean featured) {
        IsFeatured = featured;
    }

    public boolean isPromo() {
        return IsPromo;
    }

    public void setPromo(boolean promo) {
        IsPromo = promo;
    }

    public boolean isPopOut() {
        return IsPopOut;
    }

    public void setPopOut(boolean popOut) {
        IsPopOut = popOut;
    }

    public String getImageURL() {
        return ImageURL;
    }

    public void setImageURL(String imageURL) {
        ImageURL = imageURL;
    }

    public String getLocalAreaName() {
        return LocalAreaName;
    }

    public void setLocalAreaName(String localAreaName) {
        LocalAreaName = localAreaName;
    }

    public boolean isActive() {
        return Active;
    }

    public void setActive(boolean active) {
        Active = active;
    }

    public int getSubscriberID() {
        return SubscriberID;
    }

    public void setSubscriberID(int subscriberID) {
        SubscriberID = subscriberID;
    }

    public String getCreatedDate() {
        return CreatedDate;
    }

    public void setCreatedDate(String createdDate) {
        CreatedDate = createdDate;
    }

    public int getCreatedBy() {
        return CreatedBy;
    }

    public void setCreatedBy(int createdBy) {
        CreatedBy = createdBy;
    }

    public String getLastUpdated() {
        return LastUpdated;
    }

    public void setLastUpdated(String lastUpdated) {
        LastUpdated = lastUpdated;
    }

    public String getDescriptionInText() {
        return DescriptionInText;
    }

    public void setDescriptionInText(String descriptionInText) {
        DescriptionInText = descriptionInText;
    }

    public String getAddress_Component() {
        return Address_Component;
    }

    public void setAddress_Component(String address_Component) {
        Address_Component = address_Component;
    }

    public String getLocationAlias() {
        return LocationAlias;
    }

    public void setLocationAlias(String locationAlias) {
        LocationAlias = locationAlias;
    }

    public String getSubLocalityLevel() {
        return SubLocalityLevel;
    }

    public void setSubLocalityLevel(String subLocalityLevel) {
        SubLocalityLevel = subLocalityLevel;
    }

    public PropertyCategory PropertyCategory;
    public int PurposeID;
    public Purpose Purpose;
    public double LandArea;
    public int LandAreaUnitID;
    public Unit LandAreaUnit;
    public double PriceBudget;
    public int CurrencyID;
    public Currency Currency;
    public double Latitude;
    public double Longitude;
    public int Privacy;
    public boolean IsHot;
    public boolean IsFeatured;
    public boolean IsPromo;
    public boolean IsPopOut;
    public String ImageURL;
    public String LocalAreaName;
    public boolean Active;
    public int SubscriberID;
    public String CreatedDate;
    public int CreatedBy;
    public String LastUpdated;
    public String DescriptionInText;
    public String Address_Component;
    public String LocationAlias;
    public String SubLocalityLevel;

}
