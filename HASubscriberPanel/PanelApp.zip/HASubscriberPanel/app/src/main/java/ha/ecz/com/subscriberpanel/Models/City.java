package ha.ecz.com.subscriberpanel.Models;

public class City {
    public int CityID;
    public String CityName;
    public double Longitude;
    public double Latitude;
    public String CityImageUrl;
    public String CityShortCode;
    public Country Country;
}
