package in.myinnos.awesomeimagepicker.models;

/**
 * Created by MyInnos on 03-11-2016.
 */
public class Album {
    public String name;
    public String cover;

    public Album(String name, String cover) {
        this.name = name;
        this.cover = cover;
    }
}
